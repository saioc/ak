<?php
/**
 * @deprecated This file is deprecated from KINGMEDIA 3; use the below file instead.
 */

return (include QA_INCLUDE_DIR.'lang/king-lang-options.php');
