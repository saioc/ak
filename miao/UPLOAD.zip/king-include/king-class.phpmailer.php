<?php
/**
 * @deprecated This file is deprecated; please use KINGMEDIA built-in functions for sending emails.
 */

require_once 'king-vendor/PHPMailer/PHPMailerAutoload.php';
