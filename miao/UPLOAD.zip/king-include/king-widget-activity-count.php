<?php
/**
 * @deprecated This file is deprecated from KINGMEDIA 3; use the below file instead.
 */

require_once QA_INCLUDE_DIR.'king-addons/king-widget-activity-count.php';
