<?php
	header('Location: ../'); // To prevent folder inspection
?>
